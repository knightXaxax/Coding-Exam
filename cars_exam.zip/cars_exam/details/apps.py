from django.apps import AppConfig


class DetailsConfig(AppConfig):
    name = 'details'
