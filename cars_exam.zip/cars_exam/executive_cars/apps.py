from django.apps import AppConfig


class ExecutiveCarsConfig(AppConfig):
    name = 'executive_cars'
